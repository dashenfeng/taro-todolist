import { useState, useRef } from "react";
import { Button, Checkbox, View, Input } from "@tarojs/components";
import Taro, { useLoad } from "@tarojs/taro";
import "./todoList.scss";

export default function todoList() {
  const [todoList1, setTodoList1] = useState([]);
  const $InputRef = useRef();


  useLoad(()=>{
    setTodoList1(Taro.getStorageSync('todo') || [])
  })

  const createTodo = (text) => {
    return {
      text,
      checked: false,
    };
  };
  
  const onAddToDo = () => {
    const targetValue = $InputRef.current?.value
    if (!!todoList1.find((todo)=>todo.text = targetValue)) {
      // 弹窗提示
      return Taro.showToast({title:'已经添加过了！！！！！！！！！！！！！！！！！！！！！！',icon:'none'})
    }
    const newTodo = [...todoList1,createTodo(targetValue)]
    setTodoList1(newTodo);
    // 本地化存储
    Taro.setStorageSync('todo',newTodo); // 这边不能存todolist1，在存储那边会慢一拍。可能因为是异步的缘故？
  };
  const onDelToDo = (key) => {
    todoList1.splice(key, 1);
    setTodoList1([...todoList1]);
    // 本地化存储
    Taro.setStorageSync('todo',todoList1);  
  };
  const onChecked = (key) => {
    todoList1[key].checked = !todoList1[key].checked;
    setTodoList1([...todoList1]);
    // 本地化存储
    Taro.setStorageSync('todo',todoList1);
  };

  return (
    <View>
      <Input className="todo-input" ref={$InputRef}></Input>
      <Button className="todo-btn" onClick={onAddToDo}>
        添加ToDo
      </Button>
      <View>
        {todoList1.map((todo, key) => (
          <View key={key} className="todo-item">
            <View className="left" onClick={() => onChecked(key)}>
              <Checkbox checked={todo.checked}></Checkbox>
              {todo.text}
            </View>
            <View className="btn" onClick={() => onDelToDo(key)}>
              删除
            </View>
          </View>
        ))}
      </View>
    </View>
  );
}
